var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvw",
  1: "bcefgijlmnoprstuv",
  2: "bs",
  3: "abcdefghilmnoprstw",
  4: "bcdimnprsw",
  5: "r",
  6: "abcdefgilmnoprstu",
  7: "bcdflmoprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties",
  7: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties",
  7: "Events"
};

