var searchData=
[
  ['disconnected',['disconnected',['../class_bearded_man_studios_1_1_forge_1_1_networking_1_1_net_worker.html#a44dca0f3fdac91835be7e67933679d26',1,'BeardedManStudios.Forge.Networking.NetWorker.disconnected()'],['../class_bearded_man_studios_1_1_forge_1_1_networking_1_1_networking_player.html#af4e4e31e3b4b532cc8c3fc1bdfe4cae7',1,'BeardedManStudios.Forge.Networking.NetworkingPlayer.disconnected()']]]
];
